def greet_user():
    return "Hello. Welcome to My Theatre! How can I help you? [Note: Please use lowercase letters to converse.]"

def handle_user_input(user_input):
	user_input = user_input.lower()
	if 'hi' in user_input or 'hello' in user_input or 'hey' in user_input or 'hola' in user_input:
		return 'Hey there! Welcome to My Theatre! How can I help you?'
	elif 'your name' in user_input:
		return 'My name is Alex!'
	elif 'what do you do' in user_input:
		return 'I help to clear doubts with respect to the theatre and services.'
		
	elif 'movies' in user_input or 'menu' in user_input:
		return 'We offer Bollywood, Hollywood, Tollywood movies. Which movies would you like to watch?'
		if 'bollywood' in user_input:
			return 'We have Horror and Romance movies.'
		elif 'hollywood' in user_input:
			return 'We have Fantasy and Superhero movies.'
		elif 'tollywood' in user_input:
			return 'We have Action and Drama movies.'
		else:
			return
			
	elif 'types of drinks' in user_input:
		return 'We have pepsi, sprite, lemon, and coffee. Would you like to order something?'
       
		if 'i would like to take pepsi' in user_input or 'my order is pepsi' in user_input:
			return 'Nice Choice!! Your Order Is Confirmed!!'
		elif 'i would like to take sprite' in user_input or 'my order is sprite' in user_input:
			return 'Great Choice!! Your Order Is Confirmed!!'
		elif 'i would like to take lemon' in user_input or 'my order is lemon' in user_input:
			return 'Wise Choice!! Your Order Is Confirmed!!'
		elif 'i would like to take coffee' in user_input or 'my order is coffee' in user_input:
			return 'Great!! Your Order Is Confirmed!!'
		elif 'nothin' in user_input or 'nothing' in user_input:
			return
		else:
			return
			
	elif 'types of popcorn' in user_input:
		return 'We have salted, buttery, and masala popcorn.'
		if 'i would like to take salted' in user_input or 'my order is salted' in user_input:
			return 'Nice Choice!! Your Order Is Confirmed!!'
		elif 'i would like to take buttery' in user_input or 'my order is buttery' in user_input:
			return 'Great Choice!! Your Order Is Confirmed!!'
		elif 'i would like to take masala' in user_input or 'my order is masala' in user_input:
			return 'Wise Choice!! Your Order Is Confirmed!!'
		elif 'nothin' in user_input or 'nothing' in user_input:
			return
		else:
			return
			
	elif 'timings' in user_input or 'time for booking' in user_input:
		return 'We book tickets from 6 AM to 11 PM on all days!'
	elif 'discount' in user_input:
		return 'You can use this code for a 15 percent off!: MYTH'
	elif 'bye' in user_input or 'exit' in user_input:
		return 'Bye!'
	else:
		return 'Sorry, I did not understand that. Could you please try again?'

def chat():
	print(greet_user())
	while True:
		user_input = input()
		if user_input.lower() == 'bye':
			break
		response = handle_user_input(user_input)
		print(response)

if __name__ == "__main__":
	chat()


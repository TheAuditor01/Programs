import ast

class MedicalExpert:
    def __init__(self):
        self.username = ""
        self.symptoms = {}

    def load_disease_symptoms(self, filename):
        with open("disease.txt", "r") as file:
            self.disease_symptoms = ast.literal_eval(file.read())

    def ask_question(self, question):
        response = input(question + "\nPlease type Yes/No\n").strip().lower()
        return response == 'yes'

    def diagnose(self):
        matched_disease = None
        for disease, symptoms_list in self.disease_symptoms.items():
            if all(self.symptoms.get(symptom) == 'yes' for symptom in symptoms_list):
                matched_disease = disease
                break

        if matched_disease:
            print("You are suffering from the disease:", matched_disease,)
        else:
            print("No diseases found. You are healthy!")

    def run(self):
        print("Hi! I am Mr.Expert.\n\nYou can get yourself diagnosed here free of cost!\nI will ask you 10 questions.\n\n")
    
        questions = [
            ("chest pain", "Do you have chest pain?"),
            ("cough", "Do you have cough?"),
            ("fainting", "Do you faint occasionally?"),
            ("fatigue", "Do you experience fatigue occasionally?"),
            ("headache", "Do you experience headaches?"),
            ("back pain", "Do you experience back pains?"),
            ("sunken eyes", "Do you experience sunken eyes?"),
            ("fever", "Do you experience fever?"),
            ("sore throat", "Do you experience sore throat?"),
            ("restlessness", "Do you experience restlessness?"),
            ("memory loss", "Do you feel memory loss sometimes")
        ]

        for symptom, question in questions:
            self.symptoms[symptom] = 'yes' if self.ask_question(question) else 'no'

        self.diagnose()


if __name__ == "__main__":
    engine = MedicalExpert()
    engine.load_disease_symptoms("disease.txt")
    engine.run()
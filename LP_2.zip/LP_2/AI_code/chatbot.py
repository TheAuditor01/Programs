from nltk.chat.util import Chat, reflections

pairs = [
    ['my name is (.*)', ['Hello %1']],
    ['(hi|hello|hey|hola|hi)', ['Hey there! Welcome to My Theatre! How can I help you?']],
    ['(.*)your name', ['My name is Alex!']],
    ['(.*)what do you do', ['I help to clear doubts with respect to the theatre and services.']],
    ['(.*)movies|(.*)menu', ['We offer Bollywood, Hollywood, Tollywood movies.']],
    ['(.*)bollywood', ['We have Horror and Romance movies.']],
    ['(.*)hollywood', ['We have Fantasy and Superhero movies.']],
    ['(.*)tollywood', ['We have Action and Drama movies.']],
    
    ['(.*)types of drinks', ['We have pepsi, sprite, lemon, and coffee.']],
    ['(.*)i would like to take pepsi|(.*)my order is pepsi', ['Nice Choice!! Your Order Is Confirmed!!']],
    ['(.*)i would like to take sprite|(.*)my order is sprite', ['Great Choice!! Your Order Is Confirmed!!']],
    ['(.*)i would like to take lemon|(.*)my order is lemon', ['Wise Choice!! Your Order Is Confirmed!!']],
    ['(.*)i would like to take coffee|(.*)my order is coffee', ['Great!! Your Order Is Confirmed!!']],
    
    ['(.*)types of popcorn', ['We have salted, buttery, and masala popcorn.']],
    ['(.*)i would like to take salted|(.*)my order is salted', ['Nice Choice!! Your Order Is Confirmed!!']],
    ['(.*)i would like to take buttery|(.*)my order is buttery', ['Great Choice!! Your Order Is Confirmed!!']],
    ['(.*)i would like to take masala|(.*)my order is masala', ['Wise Choice!! Your Order Is Confirmed!!']],
    
    ['(.*)timings|(.*)time for booking', ['We book tickets from  6 AM to  11 PM on all days!']],
    ['(.*)discount', ['You can use this code for a 15 percent off!: MYTH']],
    ['(.*)bye|(.*)exit', ['Bye!']]
]

print("Hello. Welcome to My Theatre! How can I help you? [Note: Please use lowercase letters to converse.]")
chat = Chat(pairs, reflections)
chat.converse()

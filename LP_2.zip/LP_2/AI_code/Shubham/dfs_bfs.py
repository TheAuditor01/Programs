def dfs(visited, graph, node):
    if node not in visited:
        print(node, end=" ")
        visited.add(node)
        for neighbour in graph[node]:
            dfs(visited, graph, neighbour)

def bfs(visited, graph, node, queue):
    visited.add(node)
    queue.append(node)

    while queue:
        s = queue.pop(0)
        print(s, end=" ")
        for neighbour in graph[s]:
            if neighbour not in visited:
                visited.add(neighbour)
                queue.append(neighbour)

# Static input for the graph
graph = {
    0: [1, 2, 3],
    1: [0, 2],
    2: [1, 0, 4],
    3: [0, 4],
    4: [2, 3],
}

visited1 = set()  # To keep track of DFS visited nodes
visited2 = set()  # To keep track of BFS visited nodes
queue = []        # For BFS

print("The following is DFS")
dfs(visited1, graph, 2)

print("\nThe following is BFS")
bfs(visited2, graph, 2, queue)

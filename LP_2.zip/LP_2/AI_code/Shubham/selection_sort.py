#1
def selection_sort(arr1):
    n=len(arr1)
    for i in range(n-1):
        min = i
        for j in range(i+1,n):
            if arr1[j]<arr1[min]:
                min = j
        arr1[i],arr1[min] = arr1[min],arr1[i]

arr1 = [24, 41, 33, 42, 17]
#n = int(input("Enter No. Of Element: "))
#arr1 = []
#for i in range(n):
#    x = int(input("Enter Element: "))
#    arr1.append(x)
selection_sort(arr1)

#2
def printjobschedule(array, t):
    array.sort(key=lambda x: x[2], reverse=True)

    m = len(array)
    res = [False] * t
    job = ['-1'] * t
    job_ids = []  

    total_profit =   0
    for q in range(len(array)):
        for q in range(min(t -   1, array[q][1] -   1), -1, -1):
            if res[q] is False:
                res[q] = True
                job[q] = array[q][0]
                job_ids.append(array[q][0])  
                total_profit += array[q][2]  
                break
    print("Job IDs in decreasing order of cost:")
    for job in array:
        print(f"Job ID: {job[0]}, Deadline: {job[1]}, Cost: {job[2]}")
    print("Maximum profit sequence of jobs is- ")
    print("Total Profit:", total_profit)
    print("Job IDs in decreasing order of cost:", job_ids)

array = [['a',   3,   35],
         ['b',   4,   30],
         ['c',   4,   25],
         ['d',   2,   20],
         ['e',   3,   15],
         ['f',   1,   12],
         ['g',   2,   5]]


ch = int(input('1:- Selection Sort\n2:- Job Scheduling '))
if ch==1:
    print(arr1)
else:
    print("Maximum profit sequence of jobs is- ")
    printjobschedule(array, 4)
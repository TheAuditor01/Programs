def read_diseases_from_file(file_path):
    diseases = {}
    with open(file_path, 'r') as file:
        for line in file:
            disease, *symptoms = line.strip().split(', ')
            diseases[disease] = symptoms
    return diseases

def ask_symptoms(diseases):
    symptoms_input = {}
    for disease, symptoms in diseases.items():
        for symptom in symptoms:
            if symptom not in symptoms_input:
                symptoms_input[symptom] = input(f"Do you have {symptom}?").lower() == 'y'
    return symptoms_input

def diagnose_disease(diseases, symptoms_input):
    possible_diseases = []
    for disease, symptoms in diseases.items():
        if all(symptoms_input.get(symptom, False) for symptom in symptoms):
            possible_diseases.append(disease)
    return possible_diseases

def main():
    diseases = read_diseases_from_file('diseases.txt')
    symptoms_input = ask_symptoms(diseases)
    possible_diseases = diagnose_disease(diseases, symptoms_input)
    if possible_diseases:
        print("Possible diseases based on your symptoms:")
        for disease in possible_diseases:
            print(disease)
    else:
        print("No diseases match your symptoms.")

if __name__ == "__main__":
    main()

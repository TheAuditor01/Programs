from copy import deepcopy

DIRECTIONS = {"U": [-1, 0], "D": [1, 0], "L": [0, -1], "R": [0, 1]}
END = [[1, 2, 3], [8, 0, 4], [7, 6, 5]]


def print_puzzle(array):
    for row in array:
        print(" ".join(map(str, row)))


class Node:
    def __init__(self, current_node, previous_node, g, h, dir):
        self.current_node = current_node
        self.previous_node = previous_node
        self.g = g
        self.h = h
        self.dir = dir

    def f(self):
        return self.g + self.h


def manhattan_distance(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def heuristic(state, goal_state):
    h = 0
    for i in range(3):
        for j in range(3):
            value = state[i][j]
            if value != 0:
                goal_position = next((r, c) for r, row in enumerate(goal_state) for c, v in enumerate(row) if v == value)
                h += manhattan_distance((i, j), goal_position)
    return h


def is_goal(state, goal_state):
    return state == goal_state


def get_pos(current_state, element):
    for row in range(len(current_state)):
        if element in current_state[row]:
            return (row, current_state[row].index(element))


def getAdjNode(node):
    listNode = []
    emptyPos = get_pos(node.current_node, 0)
    for dir in DIRECTIONS.keys():
        newPos = (emptyPos[0] + DIRECTIONS[dir][0], emptyPos[1] + DIRECTIONS[dir][1])
        if 0 <= newPos[0] < len(node.current_node) and 0 <= newPos[1] < len(node.current_node[0]):
            newState = deepcopy(node.current_node)
            newState[emptyPos[0]][emptyPos[1]] = node.current_node[newPos[0]][newPos[1]]
            newState[newPos[0]][newPos[1]] = 0
            listNode.append(Node(newState, node.current_node, node.g + 1, heuristic(newState, END), dir))
    return listNode


def getBestNode(openSet):
    firstIter = True
    bestF = float('inf')
    for node in openSet.values():
        if firstIter or node.f() < bestF:
            firstIter = False
            bestNode = node
            bestF = bestNode.f()
    return bestNode


def buildPath(closedSet):
    node = closedSet[str(END)]
    branch = list()
    while node.dir:
        branch.append({
            'dir': node.dir,
            'node': node.current_node,
            'f': node.f(),
            'g': node.g,
            'h': node.h
        })
        node = closedSet[str(node.previous_node)]
    branch.append({
        'dir': '',
        'node': node.current_node,
        'f': node.f(),
        'g': node.g,
        'h': node.h
    })
    branch.reverse()
    return branch


def main(puzzle):
    open_set = {str(puzzle): Node(puzzle, puzzle, 0, heuristic(puzzle, END), "")}
    closed_set = {}
    while True:
        test_node = getBestNode(open_set)
        # print(f"Current Node: {test_node.current_node}, f(n) = {test_node.f()}, g(n) = {test_node.g}, h(n) = {test_node.h}")
        closed_set[str(test_node.current_node)] = test_node
        if is_goal(test_node.current_node, END):
            return buildPath(closed_set)
        adj_node = getAdjNode(test_node)
        for node in adj_node:
            if str(node.current_node) in closed_set.keys() or (str(node.current_node) in open_set.keys() and open_set[
                str(node.current_node)].f() < node.f()):
                continue
            open_set[str(node.current_node)] = node
        del open_set[str(test_node.current_node)]


puzzle = [[2, 8, 3], [1, 6, 4], [7, 0, 5]]
br = main(puzzle)
print('Total steps:', len(br) - 1)
print()
print("Input:")
for b in br:
    if b['dir'] != '':
        letter = ''
        if b['dir'] == 'U':
            letter = 'Direction- UP'
        elif b['dir'] == 'R':
            letter = "Direction- RIGHT"
        elif b['dir'] == 'L':
            letter = 'Direction- LEFT'
        elif b['dir'] == 'D':
            letter = 'Direction- DOWN'
        print(letter)
    print_puzzle(b['node'])
    print(f"f(n) = {b['f']}, g(n) = {b['g']}, h(n) = {b['h']}")
    print()
print('Total Cost:', len(br) - 1)
